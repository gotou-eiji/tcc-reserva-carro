<?php
include_once("../includes.php");
?>

<form action="form_carro.php" method="POST">
<center>
<button type="submit" name="salvarcarro" class="btn-secondary btn-lg ">Adicionar Carro</button>
</center>
</form>
<?php

$conn = $_SESSION["conexao"];

$sql = "SELECT * FROM carro";
$query = mysqli_query($conn, $sql);

if (mysqli_num_rows($query) > 0) {
    echo '
                    <table class="table table-dark">
                        <thead>
                            <tr>
                                <th scope="col">Id</th>
                                <th scope="col">Modelo</th>
                                <th scope="col">Placa</th>
                                <th scope="col">Preço</th>
                                <th scope="col">Imagem</th>
                            </tr>
                        </thead>
                        <tbody>';
    while ($result = mysqli_fetch_assoc($query)) {
        echo '
        <tr>
            <td>' . $result["idcarro"] . '</td>
            <td>' . $result["modelo"] . '</td>
            <td>' . $result["placa"] . '</td>
            <td>' . $result["preco"] . '</td>
            <td>
                <img src="' . $result["imagem"] . '" alt="Imagem do Carro" style="max-width: 100px; max-height: 100px;">
            </td>
            <td>
                <a href="form_carro.php?idcarro=' . $result["idcarro"] . '">
                    <button class="btn btn-danger">
                        Excluir
                    </button>
                </a>
            </td>
        </tr> 
    ';
    
    }
    echo '</tbody>';
}
?>
</table>
</div>