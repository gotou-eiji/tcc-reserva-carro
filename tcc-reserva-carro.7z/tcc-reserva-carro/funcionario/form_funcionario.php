<?php
include_once("../sessao/conexao.php");
include_once("../sessao/includes.php");
?>

<link rel="stylesheet" href="../funcionario/style2.css"  />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../funcionario/style2.css"  />

<body>

  <div class="container">
    <section class="her">
      <h2>Cadastro</h2>
    </section>
    
    <form class="form" action="cadastro_funcionario.php" method="POST" onsubmit="return validateForm()">
      <div class="form-content">
        <label for="Nome">Nome Completo</label>
        <input id="Nome" type="text" name="nome" class="form-control" placeholder="Preencha o seu nome completo" maxlength="100" required>
        <a id="nomeError" style="color: red; display: none;">O campo Nome Completo deve ser preenchido ao máximo.</a>
      </div>

      <div class="form-content">
        <label for="email">Email</label>
        <input id="email" type="email" name="email" class="form-control" placeholder="Preencha o seu e-mail" maxlength="100" required>
        <a id="emailError" style="color: red; display: none;">O campo Email deve ser preenchido ao máximo.</a>
      </div>

      <div class="form-content">
        <label for="telefone" class="form-label">Telefone</label>
        <input id="telefone" type="text" name="telefone" class="form-control" placeholder="Preencha o seu telefone" oninput="limitarTamanhoTelefone(this)" maxlength="11" required>
        <a id="telefoneError" style="color: red; display: none;">O campo Telefone deve ter 11 dígitos.</a>
      </div>
      
      <div class="form-content">                   
        <label for="funcao" class="form-label">Função</label>
        <input id="funcao" type="text" name="funcao" class="form-control" placeholder="Preencha a sua função" maxlength="100" required>  
        <a id="funcaoError" style="color: red; display: none;">O campo Função deve ser preenchido ao máximo.</a>                   
      </div>
      
      <div class="form-content">                  
        <label for="emprego" class="form-label">Emprego</label>
        <input id="emprego" type="text" name="emprego" class="form-control" placeholder="Preencha o seu emprego" maxlength="100" required>
        <a id="empregoError" style="color: red; display: none;">O campo Emprego deve ser preenchido ao máximo.</a>
      </div>
      
      <div class="form-content">                  
        <label for="data" class="form-label">Data de Nascimento</label>
        <input id="data" type="date" name="data_nascimento" class="form-control" placeholder="Preencha a sua data de nascimento" required>
        <a id="dataError" style="color: red; display: none;">O campo Data de Nascimento deve ser preenchido ao máximo.</a>
      </div>
      
      <div class="form-content">                  
        <label for="cep" class="form-label">CEP</label>
        <input id="cep" type="number" name="cep" class="form-control" placeholder="Preencha o seu CEP" oninput="limitarTamanhoCep(this)" maxlength="8" required>
        <a id="cepError" style="color: red; display: none;">O campo CEP deve ter 8 dígitos.</a>
      </div>

      <div class="form-content">                  
        <label for="cpf" class="form-label">CPF</label>
        <input id="cpf" type="number" name="cpf" class="form-control" placeholder="Preencha o seu CPF" oninput="limitarTamanhoCpf(this)" maxlength="11" required>
        <a id="cpfError" style="color: red; display: none;">O campo CPF deve ter 11 dígitos.</a>
      </div>

      <div>
        <label class="form-label">Sexo</label>
      </div>
      
      <div class="d-grid gap-4 col-100 d-md-flex justify-content-md">
        <div>
          <input type="radio" id="masculino" name="sexo" value="masculino" required>
          <label for="masculino">Masculino</label>
        </div>
        <div>
          <input type="radio" id="feminino" name="sexo" value="feminino" required>
          <label for="feminino">Feminino</label>
        </div>
        <div>
          <input type="radio" id="outros" name="sexo" value="outros" required>
          <label for="outros">Outros</label>
        </div>
      </div>
    
      <button type="submit" name="salvarfuncionario" class="btn btn-primary">Salvar</button>

    </form>

  </div>
  
  <script>
    function limitarTamanhoTelefone(input) {
      const maxLength = 11;
      if (input.value.length > maxLength) {
        input.value = input.value.slice(0, maxLength);
      }
    }
    
    function limitarTamanhoCep(input) {
      const maxLength = 8;
      if (input.value.length > maxLength) {
        input.value = input.value.slice(0, maxLength);
      }
    }
    
    function limitarTamanhoCpf(input) {
      const maxLength = 11;
      if (input.value.length > maxLength) {
        input.value = input.value.slice(0, maxLength);
      }
    }

    function validateForm() {
      var nomeError = document.getElementById("nomeError");
      var emailError = document.getElementById("emailError");
      var telefoneError = document.getElementById("telefoneError");
      var funcaoError = document.getElementById("funcaoError");
      var empregoError = document.getElementById("empregoError");
      var dataError = document.getElementById("dataError");
      var cepError = document.getElementById("cepError");
      var cpfError = document.getElementById("cpfError");
      var telefone = document.getElementById("telefone").value;
      var cep = document.getElementById("cep").value;
      var cpf = document.getElementById("cpf").value;

      if (nomeError.style.display === "block" || emailError.style.display === "block" || telefoneError.style.display === "block" || funcaoError.style.display === "block" || empregoError.style.display === "block" || dataError.style.display === "block" || cepError.style.display === "block" || cpfError.style.display === "block" || telefone.length !== 11 || cep.length !== 8 || cpf.length !== 11) {
        if (telefone.length !== 11) {
          telefoneError.style.display = "block";
        } else {
          telefoneError.style.display = "none";
        }

        if (cep.length !== 8) {
          cepError.style.display = "block";
        } else {
          cepError.style.display = "none";
        }

        if (cpf.length !== 11) {
          cpfError.style.display = "block";
        } else {
          cpfError.style.display = "none";
        }

        return false;
      }
    }
  </script>

  <!-- <script src="../funcionario/script.js"></script> -->
</body>
</html>
