<?php
include_once("../sessao/conexao.php");
include_once("../sessao/includes.php");
?>

<div class="modal-header border-bottom-0">
    <div class="container">
        <form action="cadastro_carro.php" method="POST" enctype="multipart/form-data" onsubmit="return validateForm()">
            <div class="form-group">
                <label>Marca</label>
                <input type="text" name="marca" class="form-control" placeholder="Preencha a Marca">
            </div>
            <div class="form-group">
                <label>Modelo</label>
                <input type="text" name="modelo" class="form-control" placeholder="Preencha o Modelo">
            </div>
            <div class="form-group">
                <label>Quilometragem Inicial</label>
                <input type="number" name="quilometragem_inicial" class="form-control" placeholder="Preencha a Quilometragem" oninput="validateQuilometragem(this)">
                <div id="quilometragemError" style="color: red; display: none;">A quilometragem não pode ser negativa.</div>
            </div>
            <div class="mb-3">
                <label class="form-label">Placa</label>
                <input type="text" size="7" maxlength="7" name="placa" class="form-control" placeholder="Preencha a Placa" oninput="validatePlaca(this)">
                <div id="placaError" style="color: red; display: none;">A placa deve ter pelo menos 3 letras e 4 números.</div>
            </div>
            <div class="mb-3">
                <label class="form-label">Preço</label>
                <input type="number" name="preco" class="form-control" placeholder="Preencha o Preço" oninput="validatePreco(this)">
                <div id="precoError" style="color: red; display: none;">O preço não pode ser negativo.</div>
            </div>
            <div class="mb-3">
                <label class="form-label">Motorização</label>
                <input type="text" name="motorizacao" class="form-control" placeholder="Preencha a Motorização">
            </div>
            <div class="mb-3">
                <label class="form-label">Ano</label>
                <input type="number" name="ano" class="form-control" placeholder="Preencha o Ano" oninput="validateAno(this)">
                <div id="anoError" style="color: red; display: none;">O ano deve ter 4 dígitos.</div>
            </div>
            <div class="mb-3">
                <label class="form-label">Cor</label>
                <input type="text" name="cor" class="form-control" placeholder="Preencha a Cor">
            </div>

            <div>
                <label class="form-label">Automático</label>
            </div>

            <div class="d-grid gap-4 col-100 d-md-flex justify-content-md ">
                <div>
                    <input type="radio" id="sim" name="automatico" value="sim" />
                    <label for="sim">Sim</label>
                </div>
                <div>
                    <input type="radio" id="nao" name="automatico" value="nao" />
                    <label for="nao">Não</label>
                </div>
            </div>
            <div class="mb-3">
                <label>Imagem</label>
                <input type="file" name="imagem" class="form-control-file">
            </div>

            <button type="submit" name="salvarcarro" class="btn btn-primary">Salvar</button>
            <?php
            ?>
        </form>
    </div>
</div>

<script>
    function validatePlaca(input) {
        var placa = input.value.trim();
        var letras = placa.match(/[A-Za-z]/g);
        var numeros = placa.match(/[0-9]/g);

        var placaError = document.getElementById("placaError");
        if (letras && numeros && letras.length >= 3 && numeros.length >= 4) {
            placaError.style.display = "none";
        } else {
            placaError.style.display = "block";
        }
    }

    function validateQuilometragem(input) {
        var quilometragem = parseFloat(input.value);
        var quilometragemError = document.getElementById("quilometragemError");
        if (quilometragem >= 0) {
            quilometragemError.style.display = "none";
        } else {
            quilometragemError.style.display = "block";
        }
    }

    function validatePreco(input) {
        var preco = parseFloat(input.value);
        var precoError = document.getElementById("precoError");
        if (preco >= 0) {
            precoError.style.display = "none";
        } else {
            precoError.style.display = "block";
        }
    }

    function validateAno(input) {
        var ano = input.value.trim();
        var anoError = document.getElementById("anoError");
        if (ano.length === 4) {
            anoError.style.display = "none";
        } else {
            anoError.style.display = "block";
        }
    }

    function validateForm() {
        var placaError = document.getElementById("placaError");
        var quilometragemError = document.getElementById("quilometragemError");
        var precoError = document.getElementById("precoError");
        var anoError = document.getElementById("anoError");

        if (placaError.style.display === "block" || quilometragemError.style.display === "block" || precoError.style.display === "block" || anoError.style.display === "block") {
            return false; // Impede o envio do formulário se houver erros de validação
        }

        return true; // Permite o envio do formulário se não houver erros de validação
    }
</script>
