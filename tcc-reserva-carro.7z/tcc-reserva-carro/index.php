<?php
$baseURL = "http://$_SERVER[HTTP_HOST]/tcc-reserva-carro";
header("Location: $baseURL/login/logar_funcionario.php");
exit();
?>
