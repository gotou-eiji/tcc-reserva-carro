<?php
if (!isset($_SESSION)) {
session_start();
$_SESSION['usuario_funcionario_logado'];
}
?>
