<?php 
include_once("../includes.php");
if (isset($_POST["salvarbairro"]))
{

    $conn = $_SESSION["conexao"];
    $bairro = $_POST["bairro"];
        

        if (($bairro == "") )
        {
            ?>
            <script>
                window.location.href = "form_bairro.php";
                alert("Voce precisa preencher o bairro!");    
            </script>
            <?php
        }
        else
        {
            $sql = "INSERT INTO bairro (cidade_idcidade, bairro) VALUES ('{$cidade_idcidade}', '{$bairro}')";

            $result = mysqli_query($conn, $sql);

           if (mysqli_affected_rows($conn) == 1) {
                $_SESSION["idbairro"] = mysqli_insert_id($conn);   
            }
            ?>
            <script>
                window.location.href = "cadastro_bairro.php";
                alert("Bairro cadastrado com sucesso!");
            </script>
            <?php  
}
if (!mysqli_affected_rows($conn) == 1)
{
    ?>
    <script>
        window.location.href = "cadastro_bairro.php";
        alert("Erro ao inserir bairro!");
    </script>
    <?php  
}
}
?>
