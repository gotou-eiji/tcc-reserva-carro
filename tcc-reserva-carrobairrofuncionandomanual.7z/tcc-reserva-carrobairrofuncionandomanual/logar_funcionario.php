<div class="position-absolute top-0 start-0 translate-middle"></div>

    
    <div class="col">Logar como Funcionario</h1>
    <div id="formContent">
            <div class="fadeIn first">
            </div>
            <form action="login.php" method="POST">
                    <input type="text" class="w-25 p-3" id="floatingInput" name="usuario" placeholder="login">
                    <div class="form-floating">
      <input type="password" class="w-25 p-3" id="floatingPassword" name="senha" placeholder="senha">
      <label for="floatingPassword"></label>
           </div>
           <label>
        <input type="checkbox" value="remember-me"> Me lembrar
      </label>
    </div>
                 <button class="w-25 p-3 btn-primary" type="submit" name="acessar">Logar

</div>
