<?php 
include_once("../sessao/conexao.php");
//include_once("../sessao/includes.php");
?>

<link rel="stylesheet" href="../funcionario/style2.css"  />
<link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../funcionario/style2.css"  />
<!-- <script src="./angular/funcionario.js"></script> -->

<body>
    <header>
    <nav class="nav-bar">
            <div class="logo">
                <h1>Logo</h1>
            </div>
            <div class="nav-list">
                <ul>
                    <li class="nav-item"><a href="../home/home.php" class="nav-link">Início</a></li>
                    <li class="nav-item"><a href="../funcionario/lista_funcionario.php" class="nav-link">Funcionários</a></li>
                    <li class="nav-item"><a href="../carro/lista_carro.php" class="nav-link">Carros</a></li>
                    <li class="nav-item"><a href="../historico/form_historico.php" class="nav-link">Histórico</a></li>
                    <li class="nav-item"><a href="../agendamento/form_agendamento.php" class="nav-link">Fazer Agendamento</a></li>
                </ul>
            </div>
            <div class="mobile-menu-icon">
                <button onclick="menuShow()"><img class="icon" src="../img/menu_white_36dp.svg" alt=""></button>
            </div>
        </nav>
        <div class="mobile-menu">
            <ul>
            <li class="nav-item"><a href="index.php" class="nav-link">Início</a></li>
                    <li class="nav-item"><a href="lista_funcionario.php" class="nav-link">Funcionários</a></li>
                    <li class="nav-item"><a href="lista_carro.php" class="nav-link">Carros</a></li>
                    <li class="nav-item"><a href="form_historico.php" class="nav-link">Histórico</a></li>
                    <li class="nav-item"><a href="form_agendamento.php" class="nav-link">Fazer Agendamento</a></li>
            </ul>
        </div>
    </header>

<?php
$conn = $_SESSION["conexao"];

$sql = "SELECT * FROM agendamento";
$query = mysqli_query($conn, $sql);

if (mysqli_num_rows($query) > 0) {
    echo '
        <table class="table table-dark">
            <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Data de Entrada</th>
                    <th scope="col">Data de Saída</th>
                    <th scope="col">Horário de Entrada</th>
                    <th scope="col">Horário de Saída</th>
                    <th scope="col">Motivo</th>
                    <th scope="col">Cidade</th>
                    <th scope="col">Bairro</th>
                    <th scope="col">Pagamento</th>
                </tr>
            </thead>
            <tbody>';
    while ($result = mysqli_fetch_assoc($query)) {
        echo '
            <tr>
                <td>' . $result["idagenda"] . '</td>
                <td>' . $result["entrada"] . '</td>
                <td>' . $result["saida"] . '</td>
                <td>' . $result["horario_entrada"] . '</td>
                <td>' . $result["horario_saida"] . '</td>
                <td>' . $result["motivo"] . '</td>
                <td>' . $result["cidade"] . '</td>
                <td>' . $result["bairro"] . '</td>
                <td>' . $result["pagamento"] . '</td>
            
            </tr> 
        ';
    
    }
    echo '</tbody>';
}
?>
</table>
</div>
