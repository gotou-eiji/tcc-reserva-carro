<?php 
include_once("../includes.php");
if (isset($_POST["salvarcadastro"]))
{
    $conn = $_SESSION["conexao"];

        $usuario_funcionario = $_POST["usuario_funcionario"];
        $senha_funcionario = $_POST["senha_funcionario"];
        $funcionario_idfuncionario = $_POST["idfuncionario"];
        
        if (!isset($_POST["idfuncionario"])) // Verifica se pegou idcarro, se não ele volta ao header.
        {
            header("Location:lista_funcionario.php");
        }
    

        if (($usuario_funcionario == "") || ($senha_funcionario == ""))
        {
            ?>
            <script>
                window.location.href = "form_cadastros.php";
                alert("Você precisa preencher os dados!");
    
            </script>
            <?php
        }
        else 
        {

            $sql = "INSERT INTO login_funcionario (usuario_funcionario, senha_funcionario, funcionario_idfuncionario) VALUES ('{$usuario_funcionario}', '{$senha_funcionario}', '{$funcionario_idfuncionario}')";

            $result = mysqli_query($conn, $sql);

           if (mysqli_affected_rows($conn) == 1) {
                $_SESSION["idfuncionario"] = mysqli_insert_id($conn);   
            }
            ?>
            <script>
                window.location.href = "cadastro_cadastros.php";
                alert("Cadastro efetuado com sucesso!");
            </script>
            <?php  
}
if (!mysqli_affected_rows($conn) == 1)
{
    ?>
    <script>
        window.location.href = "cadastro_cadastros.php";
        alert("Erro ao inserir cadastro!");
    </script>
    <?php  
}
}
?>