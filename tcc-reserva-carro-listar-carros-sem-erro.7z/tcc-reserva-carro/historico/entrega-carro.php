<?php
include_once("../sessao/conexao.php");
$carroId = $_POST["carro_idcarro"];
$idAgenda = $_POST["idagenda"];
$quilometragemSaida = $_POST["quilometragem_saida"];

// Atualiza a quilometragem inicial do carro
$queryAtualizacaoQuilometragem = "UPDATE carro SET quilometragem_inicial = '$quilometragemSaida' WHERE idcarro = '$carroId'";
$resultadoAtualizacaoQuilometragem = mysqli_query($conn, $queryAtualizacaoQuilometragem);

// Atualiza o valor da coluna carro_disponivel para 1 no agendamento
$queryAtualizacaoDisponibilidade = "UPDATE agendamento SET carro_disponivel = 1, data_entregue = CURRENT_TIMESTAMP WHERE idagenda = '$idAgenda'";
$resultadoAtualizacaoDisponibilidade = mysqli_query($conn, $queryAtualizacaoDisponibilidade);

// Verifica se as atualizações foram executadas com sucesso
if ($resultadoAtualizacaoQuilometragem && $resultadoAtualizacaoDisponibilidade) {
    echo "Carro entregue com sucesso!";
} else {
    echo "Ocorreu um erro ao entregar o carro.";
}

// Redireciona para a página histórico.php após a execução das atualizações
header("Location: form_historico.php");
exit();
?>
