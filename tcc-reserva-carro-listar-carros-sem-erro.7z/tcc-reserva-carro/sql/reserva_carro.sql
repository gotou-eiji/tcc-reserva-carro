-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 27/06/2023 às 21:48
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `reserva_carro`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendamento`
--

CREATE TABLE `agendamento` (
  `idagenda` int(11) NOT NULL,
  `carro_idcarro` int(11) DEFAULT NULL,
  `login_idlogin` int(11) NOT NULL,
  `funcionario_idfuncionario` int(11) NOT NULL,
  `quilometragem_inicial` int(11) NOT NULL,
  `entrada` date NOT NULL,
  `saida` date NOT NULL,
  `horario_entrada` time NOT NULL,
  `horario_saida` time NOT NULL,
  `motivo` varchar(255) NOT NULL,
  `cidade` varchar(255) NOT NULL,
  `bairro` varchar(255) NOT NULL,
  `carro_disponivel` tinyint(4) DEFAULT NULL,
  `data_entregue` timestamp NULL DEFAULT NULL,
  `pagamento` float DEFAULT NULL,
  `cliente_idcliente` int(11) DEFAULT NULL,
  `nome_cliente` varchar(255) NOT NULL,
  `nome_funcionario` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `carro`
--

CREATE TABLE `carro` (
  `idcarro` int(11) NOT NULL,
  `quilometragem_inicial` int(11) DEFAULT NULL,
  `placa` varchar(7) NOT NULL,
  `modelo` varchar(120) NOT NULL,
  `preco` float NOT NULL,
  `motorizacao` varchar(255) NOT NULL,
  `ano` int(11) NOT NULL,
  `cor` varchar(255) NOT NULL,
  `automatico` varchar(45) NOT NULL,
  `marca` varchar(45) NOT NULL,
  `imagem` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `carro`
--

INSERT INTO `carro` (`idcarro`, `quilometragem_inicial`, `placa`, `modelo`, `preco`, `motorizacao`, `ano`, `cor`, `automatico`, `marca`, `imagem`) VALUES
(14, 500, 'SNH343', 'teste', 300, '1', 2004, 'vermelho', 'nao', 'teste', '../imagens_carros/fuscao.png');

-- --------------------------------------------------------

--
-- Estrutura para tabela `cliente`
--

CREATE TABLE `cliente` (
  `idcliente` int(11) NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `telefone` int(11) NOT NULL,
  `endereco` varchar(255) DEFAULT NULL,
  `cnh` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `cliente`
--

INSERT INTO `cliente` (`idcliente`, `nome`, `telefone`, `endereco`, `cnh`) VALUES
(18, 'Emerson', 3242434, 'Rua do Santos n932', '../imagens_clientes/cnh.png');

-- --------------------------------------------------------

--
-- Estrutura para tabela `entregar_carro`
--

CREATE TABLE `entregar_carro` (
  `identregar_carro` int(11) NOT NULL,
  `agendamento_idagenda` int(11) NOT NULL,
  `kilometragem_inicial` double NOT NULL,
  `kilometragem_saida` double NOT NULL,
  `gasolina` tinyint(4) NOT NULL,
  `pneu` tinyint(4) NOT NULL,
  `farol` tinyint(4) NOT NULL,
  `banco` tinyint(4) NOT NULL,
  `janela` tinyint(4) NOT NULL,
  `motor` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `funcionario`
--

CREATE TABLE `funcionario` (
  `idfuncionario` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `cpf` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telefone` int(13) NOT NULL,
  `funcao` varchar(255) NOT NULL,
  `emprego` varchar(255) NOT NULL,
  `sexo` varchar(45) NOT NULL,
  `data_nascimento` date NOT NULL,
  `cep` varchar(45) NOT NULL,
  `numero` varchar(45) DEFAULT NULL,
  `complemento` varchar(45) DEFAULT NULL,
  `cnh` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `funcionario`
--

INSERT INTO `funcionario` (`idfuncionario`, `nome`, `cpf`, `email`, `telefone`, `funcao`, `emprego`, `sexo`, `data_nascimento`, `cep`, `numero`, `complemento`, `cnh`) VALUES
(15, 'Alexei Mardegan', 15465347, 'alexeimarde@gmail.com', 2147483647, 'Gerente', 'Muffato', 'masculino', '2000-10-14', '03404704290', NULL, NULL, NULL),
(17, 'Marcos Silva', 12364465, 'marcos2009@gmail.com', 2147483647, 'Gerente', 'Cidade Canção', 'masculino', '1999-08-10', '1234512321', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `login`
--

CREATE TABLE `login` (
  `idlogin` int(11) NOT NULL,
  `funcionario_idfuncionario` int(11) NOT NULL,
  `usuario` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `admin` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `login`
--

INSERT INTO `login` (`idlogin`, `funcionario_idfuncionario`, `usuario`, `senha`, `admin`) VALUES
(14, 15, 'admin', '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918', 1),
(16, 17, 'marcos', '43f1efecd33031b0ccd142b1c5cccc44ea19ad3e7a947965c5b0c16a632b5d7b', 0);

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `agendamento`
--
ALTER TABLE `agendamento`
  ADD PRIMARY KEY (`idagenda`),
  ADD KEY `fk_agendamento_carro1_idx` (`carro_idcarro`),
  ADD KEY `fk_agendamento_funcionario1_idx` (`funcionario_idfuncionario`),
  ADD KEY `fk_agendamento_login1_idx` (`login_idlogin`),
  ADD KEY `fk_agendamento_cliente1_idx` (`cliente_idcliente`);

--
-- Índices de tabela `carro`
--
ALTER TABLE `carro`
  ADD PRIMARY KEY (`idcarro`);

--
-- Índices de tabela `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`idcliente`);

--
-- Índices de tabela `entregar_carro`
--
ALTER TABLE `entregar_carro`
  ADD PRIMARY KEY (`identregar_carro`),
  ADD KEY `fk_entregar-carro_agendamento1_idx` (`agendamento_idagenda`);

--
-- Índices de tabela `funcionario`
--
ALTER TABLE `funcionario`
  ADD PRIMARY KEY (`idfuncionario`);

--
-- Índices de tabela `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`idlogin`),
  ADD KEY `fk_login_funcionario1_idx` (`funcionario_idfuncionario`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `agendamento`
--
ALTER TABLE `agendamento`
  MODIFY `idagenda` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT de tabela `carro`
--
ALTER TABLE `carro`
  MODIFY `idcarro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `cliente`
--
ALTER TABLE `cliente`
  MODIFY `idcliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de tabela `entregar_carro`
--
ALTER TABLE `entregar_carro`
  MODIFY `identregar_carro` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `funcionario`
--
ALTER TABLE `funcionario`
  MODIFY `idfuncionario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de tabela `login`
--
ALTER TABLE `login`
  MODIFY `idlogin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `agendamento`
--
ALTER TABLE `agendamento`
  ADD CONSTRAINT `fk_agendamento_carro1` FOREIGN KEY (`carro_idcarro`) REFERENCES `carro` (`idcarro`) ON DELETE SET NULL ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_agendamento_cliente` FOREIGN KEY (`cliente_idcliente`) REFERENCES `cliente` (`idcliente`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_agendamento_funcionario1` FOREIGN KEY (`funcionario_idfuncionario`) REFERENCES `funcionario` (`idfuncionario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_agendamento_login1` FOREIGN KEY (`login_idlogin`) REFERENCES `login` (`idlogin`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Restrições para tabelas `entregar_carro`
--
ALTER TABLE `entregar_carro`
  ADD CONSTRAINT `fk_entregar-carro_agendamento1` FOREIGN KEY (`agendamento_idagenda`) REFERENCES `agendamento` (`idagenda`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Restrições para tabelas `login`
--
ALTER TABLE `login`
  ADD CONSTRAINT `fk_login_funcionario1` FOREIGN KEY (`funcionario_idfuncionario`) REFERENCES `funcionario` (`idfuncionario`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
