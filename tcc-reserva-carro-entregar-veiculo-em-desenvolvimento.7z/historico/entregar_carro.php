<?php
if (isset($_GET['idcarro'])) {
    $idcarro = $_GET['idcarro'];

    include_once("../sessao/conexao.php");
    include_once("../sessao/includes.php");

    $conn = $_SESSION["conexao"];

    $horarioAtual = date('H:i:s');

    $sql = "UPDATE agendamento SET data_entregue = '$horarioAtual' WHERE idagenda = '$idcarro'";

    if (mysqli_query($conn, $sql)) {
        // Atualização bem-sucedida
        echo "Horário de entrega atualizado com sucesso.";
    } else {
        // Erro na execução da consulta
        echo "Erro ao atualizar o horário de entrega: " . mysqli_error($conn);
    }

    mysqli_close($conn);
} else {
    echo "Erro selecionar a alocação!";
}