<?php
include_once("../sessao/conexao.php");
include_once("../sessao/includes.php");
?>

<?php
$conn = $_SESSION["conexao"];

$sql = "SELECT * FROM agendamento";
$query = mysqli_query($conn, $sql);

if (mysqli_num_rows($query) > 0) {
    echo '
        <table class="table table-dark">
            <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Data de Entrada</th>
                    <th scope="col">Data de Saída</th>
                    <th scope="col">Horário de Entrada</th>
                    <th scope="col">Horário de Saída</th>
                    <th scope="col">Motivo</th>
                    <th scope="col">Cidade</th>
                    <th scope="col">Bairro</th>
                    <th scope="col">Data de Entrega</th>
                </tr>
            </thead>
            <tbody>';
    while ($result = mysqli_fetch_assoc($query)) {
        // Converter datas para o formato brasileiro (dd/mm/yyyy)
        $dataEntrada = date('d/m/Y', strtotime($result["entrada"]));
        $dataSaida = date('d/m/Y', strtotime($result["saida"]));
        
        echo '
            <tr>
                <td>' . $result["idagenda"] . '</td>
                <td>' . $dataEntrada . '</td>
                <td>' . $dataSaida . '</td>
                <td>' . $result["horario_entrada"] . '</td>
                <td>' . $result["horario_saida"] . '</td>
                <td>' . $result["motivo"] . '</td>
                <td>' . $result["cidade"] . '</td>
                <td>' . $result["bairro"] . '</td>
                <td>' . $result["data_entregue"] . '</td>
                <td>
                    <a href="form_entrega.php?idagenda=' . $result["idagenda"] . '">
                        <button class="btn btn-success">
                            Entregar Veículo
                        </button>
                    </a>
                </td>
            </tr> 
        ';
    
    }
    echo '</tbody>';
}
?>
</table>
</div>
