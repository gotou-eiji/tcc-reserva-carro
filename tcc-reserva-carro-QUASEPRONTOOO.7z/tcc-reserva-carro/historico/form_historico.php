<?php
include_once("../sessao/conexao.php");
include_once("../sessao/includes.php");
?>

<?php
$conn = $_SESSION["conexao"];

if ($_SESSION["admin"] == 1) {
    $sql = "SELECT agendamento.*, login.usuario FROM agendamento JOIN login ON agendamento.login_idlogin = login.idlogin";
} elseif ($_SESSION["admin"] == 0) {
    $login_idlogin = $_SESSION["idlogin"];
    $sql = "SELECT agendamento.*, login.usuario FROM agendamento JOIN login ON agendamento.login_idlogin = login.idlogin WHERE agendamento.login_idlogin = $login_idlogin";
}

$query = mysqli_query($conn, $sql);

if (mysqli_num_rows($query) > 0) {
    echo '
        <table class="table table-dark">
            <thead>
                <tr>
                    <th scope="col">Quem agendou</th>
                    <th scope="col">Data de Entrada</th>
                    <th scope="col">Data de Saída</th>
                    <th scope="col">Horário de Entrada</th>
                    <th scope="col">Horário de Saída</th>
                    <th scope="col">Motivo</th>
                    <th scope="col">Cidade</th>
                    <th scope="col">Bairro</th>
                    <th scope="col">Data de Entregue</th>
                </tr>
            </thead>
            <tbody>';
    while ($result = mysqli_fetch_assoc($query)) {
        $dataEntrada = date('d/m/Y', strtotime($result["entrada"]));
        $dataSaida = date('d/m/Y', strtotime($result["saida"]));
        $dataEntregue = date('d/m/Y', strtotime($result["data_entregue"]));
        echo '
            <tr>
                <td>' . $result["usuario"] . '</td>
                <td>' . $dataEntrada . '</td>
                <td>' . $dataSaida . '</td>
                <td>' . $result["horario_entrada"] . '</td>
                <td>' . $result["horario_saida"] . '</td>
                <td>' . $result["motivo"] . '</td>
                <td>' . $result["cidade"] . '</td>
                <td>' . $result["bairro"] . '</td>
                <td>' . $dataEntregue . '</td>
                <td>
                    <a href="form_entrega.php?idagenda=' . $result["idagenda"] . '">
                        <button class="btn btn-success">
                            Entregar Veículo
                        </button>
                    </a>
                </td>
            </tr> 
        ';
    
    }
    echo '</tbody>';
}
?>
</table>
</div>
