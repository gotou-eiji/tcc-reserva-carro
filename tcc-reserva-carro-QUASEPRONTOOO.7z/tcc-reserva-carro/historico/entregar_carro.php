<?php
include_once("../sessao/conexao.php");
include_once("../sessao/includes.php");

if (isset($_POST["entregar_carro"])) {
    $conn = $_SESSION["conexao"];
    $idagenda = $_POST["idagenda"];

    $sql = "UPDATE agendamento SET data_entregue = NOW() WHERE idagenda = '$idagenda'";

    if (mysqli_query($conn, $sql)) {    
        // Atualização bem-sucedida
        echo "Veículo entregue com sucesso!";
    } else {
        // Erro na execução da consulta
        echo "Erro ao entregar o veículo!";// . mysqli_error($conn);
    }

    mysqli_close($conn);
} else {
    echo "Erro ao selecionar a alocação!";
}
?>