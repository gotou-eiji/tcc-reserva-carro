<?php
session_start();
require_once("verifica_sessao.php");
$usuario_funcionario = $_SESSION['usuario_funcionario'];
$senha_funcionario = $_SESSION['senha_funcionario'];
$hostname = "localhost";
$database = "reserva_carro";
$user = "root";
$password = "";

$conn = mysqli_connect($hostname, $user, $password, $database);


$sql = "SELECT idlogin_funcionario FROM login_funcionario WHERE usuario_funcionario = '$usuario_funcionario' AND senha_funcionario = '$senha_funcionario'";
$query = mysqli_query($conn, $sql);
if (!$conn) {
    die(mysqli_error($sql));
} else {
    $_SESSION["conexao"] = $conn;
    $_SESSION["usuario_funcionario_logado"] = $sql;

}