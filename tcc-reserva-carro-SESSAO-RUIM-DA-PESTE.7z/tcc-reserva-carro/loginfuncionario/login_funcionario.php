<?php

require_once("../conexao.php");
// if (!isset($_SESSION)) {
//     session_start($sql = "SELECT idlogin_Funcionario FROM login_funcionario WHERE usuario_funcionario_funcionario = '{$usuario_funcionario_funcionario}' AND senha_funcionario = '{$senha_funcionario}'");
  
// }
// $sql = "SELECT idlogin_funcionario FROM login WHERE usuario_funcionario = '{$usuario_funcionario}' AND senha_funcionario = '{$senha_funcionario}'";
if (isset($_POST["acessar"])) {
    $usuario_funcionario = $_POST["usuario_funcionario"];
    $senha_funcionario = $_POST["senha_funcionario"];

    if (($usuario_funcionario == "") || ($senha_funcionario == "")) {
?>
        <script>
            window.location.href = "../index.php";
            alert("Você precisa preencher usuário e senha_funcionario para acessar o sistema!");
        </script>
        <?php

    } else {
        $response = verifica_usuario_funcionario($usuario_funcionario, $senha_funcionario);

        if ($response["response"]) {
            while ($usuario_funcionario = mysqli_fetch_assoc($response["result"])) {
                $_SESSION["usuario_funcionario_logado"] = $usuario_funcionario["nome_usuario_funcionario"];
            }

            header("Location: ../homefuncionario/home_funcionario.php");
        } else {
        ?>
            <script>
                window.location.href = "../index.php";
                alert("Usuário Não Encontrado!");
            </script>
<?php
        }
    }
}

function verifica_usuario_funcionario($usuario_funcionario, $senha_funcionario)
{
    $senha_funcionario = hash("sha256", $senha_funcionario);

    $sql = "SELECT * FROM login_funcionario WHERE usuario_funcionario = '{$usuario_funcionario}' AND senha_funcionario = '{$senha_funcionario}'";

    $result = mysqli_query($_SESSION["conexao"], $sql);

    $response["result"] = $result;

    $response["response"] = mysqli_num_rows($result) > 0 ? true : false;

    return $response;
}
